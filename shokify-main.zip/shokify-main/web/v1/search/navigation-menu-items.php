<?php
echo file_get_contents("https://catalog.roblox.com/v1/search/navigation-menu-items");
?>