<?php
$request_body = file_get_contents('php://input');
echo file_get_contents("https://groups.roblox.com/v1/groups/metadata");
?>