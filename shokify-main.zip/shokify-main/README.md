# shokify source code
# pass: shokify
Roblox Phishing Source Code UnBackdoored and Leaked 


How to use?
Extract Files

Run setup
